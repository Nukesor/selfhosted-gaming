
Thank you for downloading the Team ArenaMaster Version 3.14 Gametype for Unreal Tournament 2004!

This mod has been brought to you by:

Michael "MaStur" Massey � Project Lead
Eric "Dizzid" Chavez � Lead Programmer
Mike "ChaosTheory" Hillard - Sound Effects
Len "Enigmabyte" Bradley - Graphics
Steven "AEnubis" Phillips - Support

We are part of the team at www.3SPN.net, please feel free to stop by and visit for the latest updates and news.

If you have comments or questions, you can email them to:  mastur@3SPN.com

----------------------------------------------------------------
Version Notes
----------------------------------------------------------------

This is a point release of TAM v3.0, which is a complete 
rewrite of the ArenaMaster game mod.

Changes for version 3.0

-Team Adrenaline Combos
-Radar Adrenaline Combo (bb ff)
-Ammo Regeneration Adrenaline Combo (ll rr)
-Modified adrenaline system
-Code Optimization

Changes for version 3.1

- Fixed 2 exploits (1 serious, 1 not so serious)
- Changed the scoreboard to be less intrusive
- Added a HUD option to show extra teammate info
- Changed the statboard to be more informative
- Fixed spawning with no ammo 
- Added weapon unlock sound (can be changed in user.ini)
- Added timeouts
- Added "Most damage/accurate/headshots" output
- Fixed a crash bug when the timelimit hits 0
- Tweaked adrenaline system modifications

Changes for version 3.12

- Added option to disable footsteps.
- Tweaked the stats and score boards.
- Tweaked network information transfer.
- Added option for auto screenshot.
- Fixed brightskins for 64 bit version.
- Tweaked brightskins.
- Added option for PureRFF.
- Added commands for adren combos.
- Fixed togglebehindview inconsistancy.

Changes for version 3.14

- Re-added Teammate death sound.
- Tweak XFF system.
- Tweak RPUs to not cluster.
- 75/25 armor system.
- Add Force models.
- Fix SSDs to display bright skins.
- Force LOS hitsounds.
- Average ping on scoreboard.
- GUI Timeout button.
- Announce team combos to teammates.
- Remove radar and ammo regen
- Modify speed to show invis
- Modify berserk to regen ammo
- Optimize team combo replication
- Ammo settings in webadmin
- Truncate Speclist long names.
- Add Freon Gametype


----------------------------------------------------------------
Introduction
----------------------------------------------------------------

The ArenaMaster mod was first conceptualized in September of 2003. As part of a spirited plan to enhance Unreal Tournament,
it introduces a new form of online tournament competition for the Unreal Tournament series. Inspired by thoroughbred horse
racing, the intention behind the mod is to introduce a type of natural handicapping that would even gameplay between the 
leet and n00b players, attracting an increasing number of players. The current gametypes and levels for Unreal Tournament 
have been so mastered by skilled players that match outcomes can be predicted even before they begin. With ArenaMaster, 
the underdog in any given match will always have a chance to win. It is the belief of the ArenaMaster development team that
by leveling the playing field, this dynamic has the beneficial outcome of enhancing the overall experience of all players 
in the online gaming environment. Upon releasing the first version for beta testing in late March 2004 after the launch
of Unreal Tournament 2004, the team has play-tested this mod for tens of thousands of hours. The team incorporated a tremendous
amount of feedback producing over 40 revisions, and has added many features successfully meeting its overall objective: 
to create a game flow dynamic that leads to fun, exciting, and suspenseful gameplay.

Features:
� Contains ArenaMaster (AM), Team ArenaMaster (TAM), and Freon gametypes
� Gameplay is based on rounds; Each player has only 1 life per round
� In-game GUI administration menu for server-side settings
� In-game GUI player menu for client-side settings
� Custom Scoreboard
� Enhanced HUD displays game relevant data
� Enhanced brightskins unaffected by shadows and game lighting increases visibility beyond Epic brightskins
� Force skins can now be done in the brightskins menu, and are configureable by team
� Hitsounds can be enabled by administrator and configured by the player
� Shock Combo ammo reduced from 5 to 3
� Overtime period drains all remaining players of health at the same rate


How To Play:

1. Player spawns with full health, armor, weapons, and ammo.
2. No player can fire or be damaged during the first few seconds of play.
3. Kill all other players on the board (or opposing team players for TAM).
4. Each Kill may have bonuses attached, such as adrenaline or health
5. The last player alive receives a point (or team point). Then a new round begins.
6. The more points a player/team has, the less health and armor they spawn with
7. Score enough points (i.e. 7) and the match is won.

Freon:

Based off of freeze tag, freon is a round based game, built off of TAMs gameplay.  Instead of just killing a player 
and eliminating him from the round, he is frozen.

1. Player spawns with full health, armor, weapons, and ammo.
2. No player can fire or be damaged during the first few seconds of play.
3. Freeze all of the opposing teams players to score for your team, by dealing them lethal damage.
4. Unfreeze friendly players by standing next to them (will be indicated by a sound).
5. Recieve adrenaline for kills and damage.
6. Adrenaline combos effect your entire team.
7. Use speed combo to thaw teammates faster.
8. While unfrozen, huddle with teammates to regerate some health.
9. The more points a player/team has, the less health and armor they spawn with
10. Score enough points (i.e. 7) and the match is won.

- Thawed teammates only return with as much health as the player who thawed them.
- Lava thaws frozen players instantly.
- Huddling can only bring you close to the amount of health had by the healthiest player.
- Once your armor is gone, you can't get it back.
- Special thanks to L7 for writing the first freezetag mod for UT2kx.

----------------------------------------------------------------
Installation
----------------------------------------------------------------


-Delete all previous versions of .int, .u, and .ucl files from System Folder

-Place all files in the \UT2004\System\ folder

-For single player, select 'Instant Action' and choose the ArenaMaster or TeamArenaMaster gametype.  From within a match, 
 type 'menu3spn' into the console to bring up a full list of options and settings.

-To run a dedicated server using the ArenaMaster gametype, configure and/or add the following lines to your UT2004.ini file.

[Engine.Engine]
DefaultGame=3spnv3141.TeamArenaMaster
DefaultServerGame=3spnv3141.TeamArenaMaster

[Engine.GameEngine]
ServerPackages=3SPNv3141


[xVoting.xVotingHandler]
GameConfig=(GameClass="3SPNv3141.TeamArenaMaster",Prefix="DM",Acronym=,GameName="AM",Mutators="None",Options=)

or freon

GameConfig=(GameClass="3SPNv3141.Freon",Prefix="DM",Acronym=,GameName="FT",Mutators="None",Options=)

You could either configure the maplist via WebAdmin or under the [DefaultAM MaplistRecord] or 
[DefaultTAM MaplistRecord] section of your UT2004.ini.

-All settings are accessable only through your ut2004.ini file.

----------------------------------------------------------------
Console Commands/Keybinds
----------------------------------------------------------------


The following are custom console commands that may be bound to keys.  The commands work only for AM/TAM.

Menu3spn - opens the menu.

CallTimeout - Call a timeout.

UseBerserk - Activates Berserk adrenaline combo.

UseSpeed - Activates Speed adrenaline combo.

UseBooster - Activates Booster adrenaline combo.

UseInvis - Activates Invisible adrenaline combo.

SetSkins - changes brightskin colors. (Value can be set from 0 to 100)
Usage: SetSkins <r1> <g1> <b1> <r2> <g2> <b2>
Where the x1 variables relate to the red team OR enemies, depending on how you have it set up, and the x2 variables relate to the blue team or allies. Takes effect immediately.
Example:  SetSkins 0 100 0 100 100 100 (will set red/enemies to green, and blue/teammates to white)

DisableCombos - disable/enable certain adrenaline combos
Usage: DisableCombos <speed> <booster> <berzerk> <invis>
Each of those are a boolean (true/false) that relate to the combo of the same name. Takes effect immediately.
Example: DisableCombos true false false false (disables speed, others remain enabled)

----------------------------------------------------------------
Miscellaneous
----------------------------------------------------------------

Scoring System:
- 1 point for every kill
- 1 point for every damage unit
- Damage unit = 50% x (Starting Health + Starting Armor) [Default is 50% x (100+100) = 100]
- Hit 'HOME' key or type 'menu3spn' at console to bring up the in-game configuration screen